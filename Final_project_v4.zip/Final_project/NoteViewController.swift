//
//  NoteViewController.swift
//  Final_project
//
//  Created by user198868 on 5/19/21.
//

import UIKit

class NoteViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        noteTitle.text = globalVariables.chosenNotetitle
        noteDate.text = globalVariables.chosenNoteDate
        noteText.text = globalVariables.chosenNoteText
        
        
    }
    
    @IBOutlet weak var noteTitle: UILabel!
    
    @IBOutlet weak var noteDate: UILabel!
    
    @IBOutlet weak var noteText: UILabel!
    
}
