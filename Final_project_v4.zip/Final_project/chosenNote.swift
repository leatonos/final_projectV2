//
//  chosenNote.swift
//  Final_project
//
//  Created by user198868 on 5/19/21.
//

import Foundation

class globalVariables{
    
    static var chosenNotetitle = ""
    static var chosenNoteText = ""
    static var chosenNoteDate = ""
    

}

